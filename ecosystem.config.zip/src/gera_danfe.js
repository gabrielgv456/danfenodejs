import fs from 'fs'
import danfe from 'danfe-woj'
import path from 'path'
import { ConvertXmlToJson } from './services/convertXmlToJson.js';
import { setEmitente } from './factories/setEmitente.js';
import { returnDirName } from './media/returnDirName.js';
import { setDestinatario } from './factories/setDestinatario.js';
import { setTransportador } from './factories/setTransportador.js';
import { setProtocolo } from './factories/setProtocolo.js';
import { setImpostos } from './factories/setImpostos.js';
import { setVolumes } from './factories/setVolumes.js';
import { setProduct } from './factories/setProduct.js';
import { setDanfeInput } from './factories/setDanfeInput.js';
process.env.TZ = 'America/Sao_Paulo';

const folderPath = returnDirName();

async function processarArquivo(filename) {
    const filePath = path.join(folderPath, filename);

    if (!fs.existsSync(filePath)) return;

    console.log(`Arquivo ${filename} adicionado. Executar função...`);
    
    try {
        await generateDanfe(filePath, filename);

        fs.unlink(filePath, (err) => {
            if (err) {
                console.error(`Erro ao deletar o arquivo ${filename}:`, err);
            } else {
                console.log(`Arquivo ${filename} deletado.`);
            }
        });
    } catch (error) {
        console.error(`Erro ao processar o arquivo ${filename}:`, error);
    }
}

fs.watch(folderPath, async (eventType, filename) => {
    if (eventType === 'rename' && filename.endsWith('.xml')) {
        await processarArquivo(filename);
    }
});

fs.readdir(folderPath, async (err, files) => {
    if (err) {
        console.error('Erro ao ler os arquivos existentes:', err);
        return;
    }

    for (const file of files) {
        if (file.endsWith('.xml')) {
            await processarArquivo(file);
        }
    }
});



async function generateDanfe(filePath,filename) {

    const pathDoArquivoPdf = path.join(returnDirName(), `${path.parse(filename).name}.pdf`);
    const pathDoArquivoXml = filePath;

    try {

        const dataNf = await ConvertXmlToJson(pathDoArquivoXml)
        const emitenteNF = (dataNf.nfeProc?.NFe?.[0] ?? dataNf.NFe).infNFe[0].emit[0]
        var emitente = setEmitente(emitenteNF)

        const destinatarioNF = (dataNf.nfeProc?.NFe?.[0] ?? dataNf.NFe).infNFe[0].dest[0]
        var destinatario = setDestinatario(destinatarioNF)

        const transportadorNF = (dataNf.nfeProc?.NFe?.[0] ?? dataNf.NFe).infNFe[0].transp?.[0]
        var transportador = setTransportador(transportadorNF)

        var protocolo = setProtocolo(dataNf)

        const impostoNF = (dataNf.nfeProc?.NFe?.[0] ?? dataNf.NFe).infNFe[0].total[0].ICMSTot[0]
        var impostos = setImpostos(impostoNF)

        const volumesNF = (dataNf.nfeProc?.NFe?.[0] ?? dataNf.NFe).infNFe[0].transp?.[0].vol?.[0]
        var volumes = setVolumes(volumesNF)

        var danfeInput = setDanfeInput(dataNf, emitente, destinatario, transportador, protocolo, impostos, volumes)

        const produtos = (dataNf.nfeProc?.NFe?.[0] ?? dataNf.NFe).infNFe[0].det
        setProduct(produtos, danfeInput)

        new danfe.Gerador(danfeInput).gerarPDF({
            ambiente: 'homologacao',
            ajusteYDoLogotipo: -4,
            ajusteYDaIdentificacaoDoEmitente: 4,
            creditos: 'Safyra.com.br - Gestão do seu negócio!'
        }, function (err, pdf) {
            if (err) {
                throw err;
            }

            pdf.pipe(fs.createWriteStream(pathDoArquivoPdf));
            console.log("emitido com sucesso! Disponivel em: " + pathDoArquivoPdf)
        });

    } catch (error) {
        console.log(error.message)
    }
}
